<nav class="navbar navbar-light navbar-expand-sm d-flex">
    <div class="container"><button data-bs-toggle="collapse" data-bs-target="#navcol-1" class="navbar-toggler"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button><a class="navbar-brand" href="#">Brand</a><a class="btn btn-primary d-flex flex-sm-row-reverse order-sm-last flex-md-row-reverse" role="button" style="background: rgba(13,110,253,0);border-width: 0px;padding: 0px;padding-left: 0px;margin-left: 10px;" href="Cart.html"><i class="fas fa-shopping-cart order-sm-last" style="font-size: 22px;color: rgb(0,0,0);"></i><span id="cartCount" style="background: #ff0000;color: rgb(255,255,255);border-radius: 50%;font-size: 12px;padding: 2px 6px;">0</span></a>
        <form class="d-flex flex-fill align-content-center ms-auto" style="width: 440px;max-width: 720px;margin-top: 5px;"><input class="form-control" type="search"><button class="btn btn-primary" type="button"><i class="fas fa-search"></i></button></form>
        <div class="collapse navbar-collapse flex-grow-0 ms-auto" id="navcol-1">
            <ul class="navbar-nav d-xxl-flex ms-auto">
                <li class="nav-item d-sm-flex align-items-sm-center"><a class="nav-link active" href="Homepage.html">Home</a><a class="nav-link" href="Order.html">Order</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Warranty</a></li>
                <li class="nav-item d-flex d-xl-flex flex-grow-1 align-items-center">
                    <div class="nav-item dropstart" data-bs-smooth-scroll="true"><a aria-expanded="false" data-bs-toggle="dropdown" href="#"><i class="far fa-user" style="font-size: 24px;"></i></a>
                        <div class="dropdown-menu"><a class="dropdown-item" href="Profile.html">Profile</a><a class="dropdown-item" href="Feeback.html">Feedback</a><a class="dropdown-item" href="LoginPage_User.html">Logout</a></div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav>